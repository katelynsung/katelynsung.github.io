/*****************************************************************
//  NAME:        Katelyn Sung
//  //
//  //  HOMEWORK:    3b
//  //
//  //  CLASS:       ICS 212
//  //
//  //  INSTRUCTOR:  Ravi Narayan
//  //
//  //  DATE:        February 22, 2024
//  //
//  //  FILE:        database.c
//  //
//  //  DESCRIPTION:
//  //   Defines all of the functions for the menu
//  //
****************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "database.h"
#define FILE_NAME "bankrecord.txt"
extern int debugmode;

/*****************************************************************
//  //
//  //  Function name: addRecord
//  //
//  //  DESCRIPTION:   Adds new record into the database
//  //
//  //
//  //  Parameters:    struct record **start :
//  //                 int accountno: the account number
//  //                     char name[]: char array of user name
//  //                 char address: the street address
//  //
//  //  Return values:  0 : success
//  //                  -1 : the account number already exits or failed to find space on heap
//  //
****************************************************************/

int addRecord(struct record ** start, int uaccountno, char uname[], char uaddress[])
{
    if (debugmode == 1)
    {
        printf("!!!!DEBUGMODE!!!!\n");
        printf("The accountno: %d\n", uaccountno);
        printf("The name in the record is: %s\n", uname);
        printf("The address is: %s\n", uaddress);
    }
    int returnval = 0;
    struct record * current;
    struct record * temp;
    struct record * temp2;
    temp = (struct record *)malloc(sizeof(struct record));
    if (temp == NULL)
    {
        printf("The record is empty\n");
        returnval =  -1;
    }
    temp ->next = NULL;
    strcpy(temp->name, uname);
    strcpy(temp->address, uaddress);
    temp->accountno = uaccountno;
    printf("the new record has been added!");
    if (* start == NULL || temp -> accountno < (* start) -> accountno)
    {
        temp -> next = * start;
        * start = temp;
    }
    else
    {
        current = * start;
        while (current -> next != NULL && temp -> accountno > current -> next -> accountno)
        {
            current = current -> next;
        }
        if ( temp -> accountno == current -> accountno)
        {
            printf("Sorry this account number already exits.\n");
            returnval = -1;
        }
        else
        {
            temp -> next = current -> next;
            current -> next = temp;
        }
    }
    return returnval;
}

/*****************************************************************
//      //
//      //  Function name: printAllRecords
//      //
//      //  DESCRIPTION:   prints all the records in the data base
//      //        
//      //                 
//      //
//      //  Parameters:    struct record *start:
//      //
//      //  Return values:  void
//      //                
//      //
***************************************************************/
//

void printAllRecords(struct record *start)
{
    if (debugmode == 1)
    {
        printf("!!!!DEBUGMODE!!!!\n");
        printf("The printAllRecords function was called.\n");
        printf("The parameter is the struct record\n");
    }
    struct record * current;
    current = start;
    if (start == NULL)
    {
        printf("The list is empty");
    }

    while (current != NULL)
    {
        printf("\n%d\n %s\n %s\n", current -> accountno, current -> name, current -> address);
        current = current -> next;
    }
}

/****************************************************************

//      //   Function name: findRecord
//      //  
//      //   DESCRIPTION:   searches the database for a specific record based on 
//      //                 the account number
//     
//      //   Parameters:    struct record *start:
//      //                  int accountno : account number
//      //   Return values:  0 : success
//      //                      
****************************************************************/

int findRecord(struct record *start, int accountno)
{
    if (debugmode == 1)
    {
        printf("!!!!DEBUGMODE!!!!\n");
        printf("The function: findRecord was called\n");
        printf("The parameters are the pointer to start and the accountno: %d\n" , accountno);
    }
    int found = 0;
    struct record * current;
    current = start;
    while (current != NULL)
    {
        if (accountno == current -> accountno)
        {
            printf("%d\n %s\n %s\n", current -> accountno, current -> name, current -> address);
            return found;
        }
        else
        {
            current = current -> next;
        }
    }
    printf("There is no record with this account number\n");
    found = -1;
}

/*****************************************************************
//      //
//      //  Function name: deleteRecord
//     
//      //  DESCRIPTION:   deletes specific record from the database by    
//                         account number
//      //   Parameters:   struct record **start:
//                         int accountno: account number
//      //   Return values:  0 : success
//      
****************************************************************/

int deleteRecord(struct record **start, int accountno)
{
    if (debugmode == 1)
    {
        printf("!!!!DEBUGMODE!!!!\n");
        printf("The function: deleteRecord was called.\n");
        printf("The parameter is the pointer and %d\n", accountno);
    }
    struct record * current;
    current = * start;
    int found = -1;
    struct record * temp = NULL;
    struct record * temp2 = NULL;
    if (current == NULL)
    {
        printf("The record is empty\n");
    }
    else if (current -> accountno == accountno)
    {
        *start = current -> next;
        printf("Record deleted:\n %d\n %s\n %s\n", current -> accountno, current -> name, current -> address);
        free(current);
        found = 0;
    }
    else
    {
        while (current != NULL)
        {
            if (accountno == current -> accountno)
            {
                if (temp == NULL)
                {
                    * start = current -> next;
                }
                else
                {
                    temp2 = current -> next;
                    temp -> next = temp2;
                    printf("Record deleted:\n %d\n %s\n %s\n", current -> accountno, current -> name, current -> address);
                    free(current);
                    found = 0;
                }
            }
            temp = current;
            current = current -> next;
        }
    }
    return found;
}

/*****************************************************************
//  Function name: readfile
//  //
//  //  DESCRIPTION:   Reads the user input from the saved file
//  //                 
//  //                 
//  //
//  //  Parameters:    struct record ** start : Double pointer of start in the record
//                     char [] filename : name of file it is reading from
//  //
//  //  Return values:  0 : success
//  //                 -1 : error
//  //
******************************************************************/

int readfile(struct record ** start, char filename[])
{
    if (debugmode == 1)
    {
        printf("!!!!DEBUGMODE!!!!\n");
        printf("The function: readfile was called.\n");
        printf("The parameter is the pointer and %s", filename);
     }

    FILE *fp;
    struct record * current;
    current = * start;
    int success = 0;
    struct record * temp;
    int prevaccnum;
    char prevname[25];
    char prevaddy[45];
    int result;
    fp = fopen(filename, "r");
    printf("It is in the readfile");
    if (fp  == NULL)
    {
        success = -1;
    }
    else
    {
        while (fscanf(fp, "%d", &prevaccnum) == 1)
        {
            while (fgetc(fp) != '\n');

            fgets(prevname, sizeof(prevname), fp);
            prevname[strcspn(prevname, "\n")] = '\0';
            getaddressfromfile(prevaddy, 45, fp);
            addRecord(start, prevaccnum, prevname, prevaddy);
        }
        fclose(fp);
    }
    return success;
}

/*****************************************************************
          Function name: writefile
//  //
//  //  //  DESCRIPTION:   write all the records into a file called
//  //  //                 bankrecord.txt
//  //  //                 
//  //  //
//  //  //  Parameters:    struct record * start : pointer of start in the record
//  //                     char [] filename : name of file it is writing the data into
//  //  //
//  //  //  Return values:  0 : success
//  //  //                 -1 : error
//  //  //
******************************************************************/

int writefile(struct record * start, char filename[])
{
    if (debugmode == 1)
    {
        printf("!!!!DEBUGMODE!!!!\n");
        printf("The function: writefile was called.\n");
        printf("The parameter is the pointer and %c\n", filename);
    }
    struct record *current = start;
    int success = 0;
    FILE *outfile;
    outfile = fopen(filename, "w");
    if (outfile == NULL)
    {
        success = -1;
    }
    else if (current == NULL)
    {
        success = -1;
    }
    else
    {
        while (current != NULL)
        {
            fprintf(outfile, "\n%d\n %s\n %s\n", current -> accountno, current -> name, current -> address);
            current = current -> next;
        }
    }
    fclose(outfile);
    return success;
}

/*****************************************************************
//  //  //          
//  //  // Function name: cleanup
//  //  //  DESCRIPTION:   releases all the allocated spaces in the heap memory    
/   //  //                 and assigns NULL to start                
//  //  //
//  //  //  Parameters:    struct record ** start : double pointer of start in the record
//  //  //    
//  //  //  Return values:  VOID
//  //  //  //
******************************************************************/

void cleanup(struct record ** start)
{
    if (debugmode == 1)
    {
        printf("!!!!DEBUGMODE!!!!\n");
        printf("The function: cleanup was called\n");
    }
    struct record * current;
    current = * start;
    struct record * next;
    while (current != NULL)
    {
        next = current -> next;
        free(current);
        current = next;
    }
    * start = NULL;
}

/*****************************************************************
//  //  //          
//  //  //  //    Function name: getaddressfromfile
//  //  //  //  DESCRIPTION: Reads address from the txt file taking it the way    
//  /   //  //                        the user inputs it
//  //  //  //
//  //  //  //  Parameters:    char[] : array of address
//  //  //  //                 int : size of char array
//                             FILE*: file pointer
//  //  //  //  Return values:  VOID
//  //  //  //  
******************************************************************/

void getaddressfromfile(char prevaddy[], int size, FILE * fp)
{
    char faddy;
    int index = 0;
    int end = 0;
    char prev_char = '\0';
    if (debugmode == 1)
    {
        printf("!!!! DEBUGMODE !!!!\n");
        printf("The getaddressfromfile function was called\n");
        printf("The paramenters are %s %d" , prevaddy, size);
    }
    while ((faddy = fgetc(fp)) != EOF && index < size - 1 && !end)
    {
        if (faddy == '\n' && prev_char == '\n')
        {
            end = 1;
        }
        else
        {
            prevaddy[index] = faddy;
            index++;
        }
        prev_char = faddy;
    }
    prevaddy[index] = '\0';
}
