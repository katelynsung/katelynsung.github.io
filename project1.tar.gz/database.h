/*****************************************************************
//  //  //  NAME:        Katelyn Sung
//  //
//  //  //  HOMEWORK:    1
//  //  //
//  //  //  CLASS:       ICS 212
//  //  //
//  //  //  INSTRUCTOR:  Ravi Narayan
//  //  //
//  //  //  DATE:        February 22, 2024
//  //  //
//  //  //  FILE:        database.h
//  //  //
//  //  //  DESCRIPTION:
//  //  //   function prototypes
//  //  //
****************************************************************/

#ifndef DATABASE_H
#define DATABASE_H
#include "record.h"

int addRecord(struct record ** start, int uaccountno, char uname[], char uaddress[]);
void printAllRecords(struct record *);
int findRecord(struct record *, int);
int deleteRecord(struct record **, int);
int writefile(struct record *, char[]);
int readfile(struct record **, char[]);
void cleanup(struct record **);
void getaddressfromfile(char[], int, FILE*);

#endif /* DATABASE_H */
