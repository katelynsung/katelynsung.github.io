/*****************************************************************
//
//  //  NAME:        Katelyn Sung
//  //
//  //  HOMEWORK:    3b
//  //
//  //  CLASS:       ICS 212
//  //
//  //  INSTRUCTOR:  Ravi Narayan
//  //
//  //  DATE:        February, 9, 2024
//  //
//  //  FILE:        user_interface.c
//  //
//  //  DESCRIPTION:
//  //   This file contains the user_interface and main method, writing the user input into a file
//  //  
//  //
****************************************************************/

#include <stdio.h>
#include <string.h>
#include "record.h"
#include "database.h"
void getAddress(char[], int);

/*****************************************************************
//  Function name: main
//  //
//  //  DESCRIPTION:   prints the menu options as well as verifies if the 
//  //                 userinput is valid
//  //
//  //  Parameters:    argc: 
//                     argv[]   
//  //                              
//  //
//  //  Return values:  0 : not quit
//  //                 
//  //
//  **************************************************************/                                 

int debugmode = 0;
int main(int argc, char* argv[])
{
    struct record * start = NULL;
    char userInput[10];
    char addy[45];
    int choice;
    int accnum;
    char name[25];
    int validInput = 0;
    int result;
    int control = 1;
    int num;
    char buffer[100];
    char filename[20] = "bankrecord.txt";
    if ((argc == 2) && (strcmp("debug", argv[1]) == 0))
    {
        debugmode = 1;
    }
    else if (argc > 1)
    {
        control = 0;
        printf("Error");
    }
    if (control == 1)
    {
        readfile(&start, filename);
        do
        {
            printf("\nWelcome, this user interface will manage your bank records.\n\n\n");
            printf("To select your choice please type in one of the following choices:\n\n");
            printf("add: Add a new record to the database\n");
            printf("printall: Print all records in the database\n");
            printf("find: Find record(s) with a specified account #\n");
            printf("delete: Delete existing record(s) from the database using the account #\n");
            printf("quit: Quit the program\n\n");
            printf("Please enter your choice: \n");
            scanf("%s", userInput);
            choice = strncmp(userInput, "quit", strlen(userInput));
            if (strncmp(userInput, "add", strlen(userInput)) == 0)
            {
                validInput = 0;
                printf("You have chosen to add a new record into the database\n");
                printf("Please enter your account number:\n");
                result = scanf("%d", &accnum);
                if (result == 1 && accnum > 0)
                {
                    validInput = 1;
                }
                while (validInput == 0)
                {
                    fgets(buffer, 100, stdin);
                    printf("Please enter a positive integer greater than 0:\n");
                    scanf("%d", &accnum);
                    if (accnum > 0)
                    {
                        validInput = 1;
                    }
                }
                printf("You choose the account number: %d\n", accnum);
                fgets(buffer, 100, stdin);
                printf("Please enter your name:\n");
                fgets(name, 25, stdin);
                printf("Name inputted: %s", name);
                getAddress(addy, 45);
                addRecord(&start, accnum, name, addy);
            }
            else if (strncmp(userInput, "printall", strlen(userInput)) == 0)
            {
                printf("You have chosen to print all\n");
                printAllRecords(start);
            }
            else if (strncmp(userInput, "find", strlen(userInput)) == 0)
            {
                validInput = 0;
                printf("You have entered find\n");
                printf("Please enter your account number:\n");
                result = scanf("%d", &accnum);
                if (result == 1 && accnum > 0)
                {
                    validInput = 1;
                }
                while (validInput == 0)
                {
                    printf("this is the chosen account number: %d\n", accnum);
                    while (getchar() != '\n' || accnum <= 0)
                    {
                        printf("Please enter a positive integer greater than 0:");
                        scanf("%d", &accnum);
                    }
                    validInput = 1;
                }
                printf("this is the chosen account number: %d\n" , accnum);
                findRecord(start, accnum);
            }
            else if (strncmp(userInput, "delete", strlen(userInput)) == 0)
            {
                validInput = 0;
                printf("You have chosen to delete\n");
                printf("Please enter the accound number you want to delete:\n");
                result = scanf("%d", &accnum);
                if (result == 1 && accnum > 0)
                {
                    validInput = 1;
                }
                while (validInput == 0)
                {
                    fgets(buffer, 100, stdin);
                    printf("Please enter a positive integer greater than 0:\n");
                    scanf("%d", &accnum);
                    if (accnum > 0)
                    {
                        validInput = 1;
                    }
                }
                printf("this is account number chosen to be deleted: %d\n", accnum);
                deleteRecord(&start, accnum);
            }
            else
            {
                if (choice != 0)
                {
                    printf("Invalid input please type in one of the valid choices\n");
                }
            }
        }
        while (choice != 0);
        if (choice == 0)
        {
            printf("Quitting program.");
            writefile(start, filename);
            cleanup(&start);
        }
    }
    return 0;
}

/*****************************************************************
// //
//  //  Function name: getAddress
//  //  //
//  //  //  DESCRIPTION:   obtains inputted address from user
//  //  //                 
//  //  //
//  //  //  Parameters: addy[]:array of characters  
//  //  //              int length :size of the array       
//  //  //
//  //  //  Return values:  VOID
//  //  //                 
//  //  //
//  //  **************************************************************/

void getAddress(char addy[], int length)
{
    char address;
    int index = 0;
    int end = 0;
    char prev_char;
    if (debugmode == 1)
    {
        printf("!!!! DEGBUGMODE!!!!\n");
        printf("The getAddress function was called\n");
        printf("The parameters are the char array[] and the address: %d\n", length);
    }
    printf("Please enter your address:\n");
    printf("Please enter the 'enter button' twice at the end of your address\n");
    while (index < length -1 && address != EOF && end != 1)
    {
        address = getchar();
        if (address == '\n')
        {
            if (prev_char == '\n')
            {
                end = 1;
            }
        }
        addy[index] = address;
        prev_char = address;
        index++;
    }
    addy[index] = '\0';
    printf("The inputted address is: %s\n" , addy);
}
