/*****************************************************************
//  //  //  NAME:        Katelyn Sung
//  //
//  //  //  HOMEWORK:    3b
//  //  //
//  //  //  CLASS:       ICS 212
//  //  //
//  //  //  INSTRUCTOR:  Ravi Narayan
//  //  //
//  //  //  DATE:        February 22, 2024
//  //  //
//  //  //  FILE:        record.h
//  //  //
//  //  //  DESCRIPTION:
//  //  //   Define struct record
//  //  //
//  //  ****************************************************************/

#ifndef RECORD_H
#define RECORD_H

struct record
{
    int                accountno;
    char               name[25];
    char               address[45];
    struct record*     next;
};
#endif
